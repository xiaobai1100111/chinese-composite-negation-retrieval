SUPPLEMENTARY DATA AND SCORE RECHECK

Article title: Supervision tradeoffs in Chinese text-to-image retrieval with composite negation
Prepared for Pattern Recognition Letters
Author: Runze Zhang
Affiliation: College of Information Science and Engineering, Huaqiao University,
Xiamen 361021, China
Corresponding author: Runze Zhang, roude@stu.hqu.edu.cn

This package accompanies the PRL concise revision based on the R4 results. Current Study II
uses 157 retained families and 471 images after joint human review. Original
160-family results remain separately identified as historical evidence.
The three exclusions were fixed before revised aggregation. No new training
or model scores were produced for this revision.

RUN FROM ANY LOCATION
Requirements: Python 3 and NumPy. No GPU, model/image download or machine-specific
path is needed for these commands. Run in the root of the extracted ZIP:

    python verify_file_integrity.py
    python verify_revised_scores.py
    python verify_budget_scores.py

The scripts print JSON results and do not modify package contents.
verify_revised_scores.py checks 9,360 saved-array endpoint values: 52 configurations
x five type/overall scopes x three source/balanced scopes x 12 metrics. It checks
legal Top-1 for four query forms in two-/three-image pools, per-family polarity
products before averaging, and missing-A/present-B errors.
verify_budget_scores.py checks 6,480 negative three-image Top-1/error values across
96 checkpoints, 32 seed means and 16 C3-C2 contrasts, with five scopes and three
source/balanced summaries. Exact stored float32 ties split probability mass equally.

These checks verify aggregation from saved scores. They do not rerun training,
independently validate labels, reproduce embeddings, test every cosine margin,
or independently rebuild every dependency-deletion statistic. Complete saved
results, including these other metrics, remain included for inspection.

LAYOUT
prl_tables/                   Current PRL main Table1 and Table2, display-ready TSVs
tables/                       Current supplementary S1-S27, plus retained R4 full-report
                              main Table1-Table5 (NOT the PRL main numbering)
tables/csv/                   Equivalent UTF-8 CSVs for the retained 30 R4 tables and S26/S27
tables/raw_values/            Unrounded source values and unit annotations
data/study2/                  Current retained 157-family complete analysis
data/budget/                  Current 157-family budget analysis
data/history/study2/          Original 160-family Study II analysis
data/history/budget/          Original 160-family budget analysis
data/history/tables_R3/       Prior main and supplementary display tables
data/human_review/            Joint original set, seven-image follow-up, final
                              answers, correction/exclusion manifest, retained
                              families and original frozen families
scores/study2/B16 and L14/    Original 26-configuration arrays per backbone
scores/budget/B16 and L14/    Original 48-checkpoint arrays/manifests per backbone
additional_data/ordinary_retrieval_results.json
                              Unchanged ordinary-retrieval control
figures/Figure_S1.png         Revised budget sensitivity plot
verification/                Existing author-run checks and revision differences
SHA256_manifest.json         Relative paths, byte counts and SHA256 hashes
table_manifest.json          Table dimensions, hashes, versions and numerical sources
tables/cell_sources.json      Current Study II cell-level JSON pointers

Original score arrays retain all 160 families unchanged. Verifiers select 157
by frozen retained/excluded IDs. The original frozen family file contains 160
main and 32 unscored reserve families. Current Study II numerical results are unchanged from the R4 author-side analysis.
Selected provenance-path metadata are normalized in this release.
See PUBLIC_RELEASE_NOTES.txt and PUBLIC_PROVENANCE.json.
Provenance locators are metadata only; executable checks use package-relative paths.
The provenance:// roots are not downloadable URLs.

WEIGHTS AND UNITS
Counts are entity 38, color 40, action/interaction 40 and state 39. COCO/Flickr
counts are 19/19, 20/20, 20/20 and 20/19 respectively. Each source retains weight
1/2 within a type; each type retains weight 1/4 overall. This is not a microaverage
of 157 families. Deterministic C0/Seeing_local configurations are not three seeds.
Display tables use manuscript rounding. Source rates and differences in raw_values
require multiplication by 100 for percent/percentage-point display as annotated.
S24/S25 columns ending _rate contain rates; _pp columns already contain percentage
points. Do not multiply a _pp column by 100 again.

HUMAN REVIEW
Two non-author reviewers discussed one joint answer set, then jointly clarified
seven images. The author did not participate in these new judgments. There are
no separate pre-discussion answers; this is non-author joint verification, not
an independent interrater reliability study. The two files are the initial joint
set and its follow-up, not one file per reviewer.
The old portal schema name and independence_attested=true field remain in the
original export. They are interface metadata and do not establish independent
ratings. REVIEW_PROCESS.json records the clarified process. R01 is a pseudonymous
portal ID; reviewer names and contact details are absent. Original answers are
copied byte-for-byte under neutral filenames.

NOT INCLUDED
Source images and model weights are not redistributed. This is a saved-score
recheck package, not a full training-reproduction archive. Image identifiers and
recorded facts/provenance are provided. Later image access or redistribution
must follow original dataset terms. No new p-values or confidence intervals
are claimed; deletion ranges describe fixed-set sensitivity.

PRL EDITORIAL MAPPING
The revised main paper contains two tables and one figure. Current main tables
are in prl_tables/. The unchanged tables/Table1-Table5 remain the R4 full-report
tables for traceability; they must not be mistaken for the PRL main numbering.
S26 reproduces R4 main Table2 (earlier thousand-image comparisons). S27 reproduces
R4 main Table3 (entity results, source differences and deletion ranges).
S1-S25 and all raw scores/labels/results are unchanged. Current main Table2
selects columns from R4 main Table3; differences were computed before rounding.
Main Figure1 plots the two error differences from R4 main Table4. The figure
format changes only, not its numerical values.

A DETERMINISTIC DISPLAY CHECK
    python verify_prl_tables.py
This checks the current main success table, S26/S27 mapping, and the figure values
against the included full-report tables. It complements, but does not replace,
the direct saved-score checks above.


PRL review revision R2, 10 November 2026
Table S28 displays original-160 versus retained-157 primary entity differences.
The numerical study data and saved scores are unchanged from the preceding PRL review package.
Joint polarity means full-negation success times affirmative success within family/seed, NOT A-only times not-B-only.
verification/overlap_audit.json and study1_overlap_audit.json document project image separation checks; any source paths refer to the original project archive and are not distributed image pixels.
plot_figure_1.py reproduces the main figure from tables/Table4.tsv; it requires Python, NumPy and Matplotlib and writes generated_figures/. The PDF/SVG/EPS outputs are vector graphics; PNG is 600 dpi.
This ZIP supplies saved-score verification and plotting. It is not a complete training or image-embedding inference environment. At preparation, no repository DOI or public deposition has been assigned.

LICENSED RELEASE 1.0
Prepared on 11 November 2026. At preparation this release had not been
deposited or published and had no assigned repository DOI or publication date.
The repository landing page will supply the public record details after deposit.
Data and documentation are CC BY 4.0 to the extent Runze Zhang has rights to
license them; the five original Python scripts listed in LICENSING.txt are MIT.
Third-party rights remain unchanged. Read LICENSING.txt, THIRD_PARTY_NOTICES.txt,
PUBLIC_RELEASE_NOTES.txt and RELEASE_RECORD.json. Scientific data are unchanged
from the validated public candidate.

SUPPLEMENTARY DATA USE
This same archive may accompany the manuscript as Supplementary Data.
The external ZIP filename may be Supplementary_Data_and_Score_Recheck.zip.
Verification and plotting scripts resolve paths from the extracted package root;
they do not depend on the external ZIP filename. Renaming the outer archive does
not change its contents, version, licenses or SHA256 hash.
