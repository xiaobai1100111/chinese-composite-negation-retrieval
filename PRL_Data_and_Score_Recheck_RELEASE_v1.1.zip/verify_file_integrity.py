"""Check released files against the portable SHA256 manifest."""
from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
 p=root/item['path']
 assert p.is_file(),item['path']
 assert p.stat().st_size==item['bytes'],item['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
print(json.dumps({'passed':True,'verified_files':len(manifest['files'])}))
