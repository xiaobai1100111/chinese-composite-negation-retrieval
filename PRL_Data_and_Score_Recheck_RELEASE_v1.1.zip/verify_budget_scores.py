"""Check revised budget Top-1/errors from unchanged float32 arrays."""
import json
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent
SOURCE=H/'scores/budget'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
excluded=set(read(H/'data/human_review/exclusion_and_label_correction_manifest.json')['excluded_family_ids'])
fams=read(H/'data/human_review/original_frozen_families_192.json')['families']
types=('entity','color','action_interaction','state');sources=('COCO','Flickr')
fmap={f['family_id']:f for f in fams if f['allocation']=='main'}
rows={r['new_ranker_id']:r for r in read(H/'data/budget/single_configuration_endpoints.json')}
means=read(H/'data/budget/seed_averaged_endpoints.json')
pairs=read(H/'data/budget/paired_comparisons.json')
vectors={};records=[];checked=0;maxerr=0.
def check(a,b):
 global checked,maxerr
 err=abs(float(a)-float(b));assert err<1e-12,(a,b);checked+=1;maxerr=max(maxerr,err)
def aggregate(vals,families,label,source=None):
 ts=types if label=='overall_equal_four_types' else (label,)
 ss=sources if source is None else (source,)
 bins=[]
 for t in ts:
  for s in ss:
   ix=[i for i,f in enumerate(families) if f['type']==t and f['source']==s]
   assert ix;bins.append(vals[ix].mean(axis=0))
 return np.array(bins).mean(axis=0)
metrics=('negative_top1_3pool','B_present_error','A_missing_error')
for bb in ('B16','L14'):
 manifest=read(SOURCE/bb/'score_manifest.json');records+=manifest
 with np.load(SOURCE/bb/'scores_float32.npz',allow_pickle=False) as z:
  assert z['ranker_ids'].tolist()==[r['new_ranker_id'] for r in manifest]
  assert z['query_kinds'].tolist()==['negative','positive','A_only','not_B_only']
  assert z['roles'].tolist()==['A_not_B','A_B','not_A_not_B']
  ids=z['family_ids'].tolist();mask=np.array([fid not in excluded for fid in ids]);ff=[fmap[fid] for fid in ids if fid not in excluded]
  assert len(ff)==157
  negative=z['scores'][:,mask,0,:]
  tied=negative==negative.max(axis=-1,keepdims=True)
  masses=tied/tied.sum(axis=-1,keepdims=True)
  for i,r in enumerate(manifest):
   rid=r['new_ranker_id'];vectors[rid]=masses[i]
   for label in (*types,'overall_equal_four_types'):
    for s in (None,*sources):
     v=aggregate(masses[i],ff,label,s)
     expected=rows[rid]['summaries'][label]['source_balanced' if s is None else 'by_source']
     if s is not None:expected=expected[s]
     for j,k in enumerate(metrics):check(v[j],expected[k])
mean_vectors={}
for r in means:
 key=(r['backbone'],r['condition'],r['learning_rate'],r['step'])
 ids=[x['new_ranker_id'] for x in records if (x['backbone'],x['condition'],x['learning_rate'],x['step'])==key]
 assert len(ids)==3;v=np.mean([vectors[i] for i in ids],axis=0);mean_vectors[key]=v
 for label in (*types,'overall_equal_four_types'):
  for s in (None,*sources):
   actual=aggregate(v,ff,label,s);expected=r['summaries'][label]['source_balanced' if s is None else 'by_source']
   if s is not None:expected=expected[s]
   for j,k in enumerate(metrics):check(actual[j],expected[k])
for r in pairs:
 key=(r['backbone'],r['learning_rate'],r['step']);b,lr,step=key
 v=mean_vectors[(b,'C3',lr,step)]-mean_vectors[(b,'C2',lr,step)]
 for label in (*types,'overall_equal_four_types'):
  for s in (None,*sources):
   actual=aggregate(v,ff,label,s);expected=r['effect_summaries'][label]['source_balanced' if s is None else 'by_source']
   if s is not None:expected=expected[s]
   for j,k in enumerate(metrics):check(actual[j],expected[k])
assert checked==6480
result={'passed':True,'independent_algorithm':'NumPy max equality tie masses and explicit per-type/source bin means; no frozen algebra imported','single_configs':96,'seed_means':32,'paired_conditions':16,'metrics':list(metrics),'numeric_checks':checked,'max_abs_error':maxerr,'correct_weighting_after_unequal_exclusions':True,'not_new_model_inference':True}
print(json.dumps(result))
