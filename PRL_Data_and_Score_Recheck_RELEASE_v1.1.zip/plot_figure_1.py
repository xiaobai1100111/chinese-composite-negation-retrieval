from pathlib import Path
import json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
H=R/'generated_figures'
H.mkdir(exist_ok=True)
def plot_figure():
    rows=list(csv.reader((R/'tables'/'Table4.tsv').open(encoding='utf-8-sig'),delimiter='\t'))[1:]
    vals=np.array([[float(v[2]),float(v[3])] for v in rows])
    plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8.8,'pdf.fonttype':42,'ps.fonttype':42})
    fig,ax=plt.subplots(figsize=(3.333,3.05))
    y=np.arange(4);h=.31
    for j,(label,col,hatch) in enumerate([('Missing-A error','#218574','///'),('Present-B error','#bd623b','xx')]):
        bars=ax.barh(y+(j-.5)*h,vals[:,j],height=h,label=label,color=col,edgecolor='black',linewidth=.4)
        for b,v in zip(bars,vals[:,j]):
            ax.text(v+(.55 if v>=0 else -.55),b.get_y()+h/2,f'{v:+.2f}'.replace('-', '−'),va='center',ha='left' if v>=0 else 'right',fontsize=8.5)
    ax.set_yticks(y,['B/16\n1×10⁻⁶','B/16\n3×10⁻⁶','L/14\n1×10⁻⁶','L/14\n3×10⁻⁶']);ax.invert_yaxis()
    ax.axvline(0,color='black',lw=.7);ax.set_xlim(-32,32);ax.set_xticks([-20,0,20]);ax.set_xlabel('Error change C3 − C2 (pp)',fontsize=8.5)
    ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0)
    ax.xaxis.grid(True,color='#dddddd',lw=.5);ax.set_axisbelow(True)
    ax.legend(loc='lower left',bbox_to_anchor=(-.18,1.01),frameon=False,fontsize=8.7,ncol=1,handlelength=1.7,borderaxespad=0)
    fig.subplots_adjust(left=.2,right=.99,bottom=.16,top=.79)
    for suf in ['png','pdf','svg','eps']:fig.savefig(H/f'Figure_1.{suf}',dpi=600)
    (H/'figure_values.json').write_text(json.dumps({'source':'R4 Manuscript Table4','values':vals.tolist(),'figure':'Two error changes; success reported in main Table2'},indent=2),encoding='utf-8')
    plt.close(fig)

plot_figure()
