from pathlib import Path
import csv,json
P=Path(__file__).resolve().parent
def read(p): return list(csv.reader((P/p).open(encoding='utf-8-sig'),delimiter='\t'))
a=read('tables/Table3.tsv');b=read('prl_tables/Table2.tsv')
assert len(b)==5
for x,y in zip(a[1:],b[1:]):assert y==[x[0]+', '+x[1],x[3],x[2],x[4].replace('-', '−')]
assert read('tables/S26.tsv')==read('tables/Table2.tsv')
assert read('tables/S27.tsv')==a
f=json.loads((P/'verification/PRL_figure_values.json').read_text('utf-8'))
assert f['values']==[[float(x[2]),float(x[3])] for x in read('tables/Table4.tsv')[1:]]
expected=[['C1','A; B; A ∧ B'],['C2','B; ¬B'],['C3','A ∧ B; A ∧ ¬B'],['C4','B; ¬B; A ∧ B; A ∧ ¬B']]
assert read('prl_tables/Table1.tsv')[1:]==expected
print(json.dumps({'passed':True,'primary_rows':4,'supplement_rows':8,'figure_values':8,'supervision_rows':4}))

old=json.loads((P/'data/history/study2/paired_comparisons.json').read_text(encoding='utf-8-sig'))
cur=json.loads((P/'data/study2/paired_comparisons.json').read_text(encoding='utf-8-sig'))
for row in read('tables/S28.tsv')[1:]:
    backbone=row[0].replace('/','');lr=1e-6 if row[1].startswith('1') else 3e-6
    for data,display in [(old,row[2]),(cur,row[3])]:
        match=[x for x in data if x['backbone']==backbone and x['learning_rate']==lr and x['target']=='C3' and x['comparator']=='C2' and x['type']=='entity']
        assert len(match)==1
        v=match[0]['effects']['negative_top1_3pool']*100
        assert f'{v:+.2f}'.replace('-','−')==display
print(json.dumps({'S28_verified_rows':4,'new_scores_or_training':False}))

old=json.loads((P/'data/history/study2/paired_comparisons.json').read_text(encoding='utf-8-sig'))
cur=json.loads((P/'data/study2/paired_comparisons.json').read_text(encoding='utf-8-sig'))
for row in read('tables/S28.tsv')[1:]:
    backbone=row[0].replace('/','');lr=1e-6 if row[1].startswith('1') else 3e-6
    for data,display in [(old,row[2]),(cur,row[3])]:
        match=[x for x in data if x['backbone']==backbone and x['learning_rate']==lr and x['target']=='C3' and x['comparator']=='C2' and x['type']=='entity']
        assert len(match)==1
        v=match[0]['effects']['negative_top1_3pool']*100
        assert f'{v:+.2f}'.replace('-','−')==display
print(json.dumps({'S28_verified_rows':4,'new_scores_or_training':False}))
