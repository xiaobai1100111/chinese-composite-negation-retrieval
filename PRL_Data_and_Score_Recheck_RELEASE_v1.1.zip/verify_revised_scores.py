"""Check revised Study II endpoints from unchanged float32 arrays."""
from pathlib import Path
import json, hashlib, math
import numpy as np
ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ex=read(ROOT/'data/human_review/exclusion_and_label_correction_manifest.json')
keep=set(ex['retained_family_ids'])
all_fams=read(ROOT/'data/human_review/original_frozen_families_192.json')['families']
fm={f['family_id']:f for f in all_fams if f['family_id'] in keep}
assert len(keep)==len(fm)==157
endpoints=read(ROOT/'data/study2/single_configuration_endpoints.json')
byrid={r['ranker_id']:r for r in endpoints}
kinds=['negative','positive','A_only','not_B_only']
legal=[{0},{1},{0,1},{0,2}]
types=['entity','color','action_interaction','state']
sources=['COCO','Flickr']
checked=0;max_error=0
for bb in ['B16','L14']:
    path=ROOT/'scores/study2'/bb/'scores_float32.npz'
    with np.load(path,allow_pickle=False) as z:
        assert z['query_kinds'].tolist()==kinds and z['roles'].tolist()==['A_not_B','A_B','not_A_not_B']
        fids=z['family_ids'].tolist();rids=z['ranker_ids'].tolist();scores=z['scores']
        for ri,rid in enumerate(rids):
            metric_values={}
            for fi,fid in enumerate(fids):
                if fid not in keep:continue
                one={}
                for size in [2,3]:
                    for qi,q in enumerate(kinds):
                        a=scores[ri,fi,qi,:size]
                        tied=np.flatnonzero(a==a.max()).tolist()
                        one[f'{q}_top1_{size}pool']=sum(j in legal[qi] for j in tied)/len(tied)
                        if q=='negative' and size==3:
                            one['A_missing_error']=sum(j==2 for j in tied)/len(tied)
                            one['B_present_error']=sum(j==1 for j in tied)/len(tied)
                    one[f'both_polarities_success_{size}pool']=one[f'negative_top1_{size}pool']*one[f'positive_top1_{size}pool']
                metric_values[fid]=one
            for label,which_types in [(t,[t]) for t in types]+[('overall_equal_four_types',types)]:
                for source in [None]+sources:
                    wanted=[(t,s) for t in which_types for s in ([source] if source else sources)]
                    bins=[[metric_values[fid] for fid in metric_values if fm[fid]['type']==t and fm[fid]['source']==s] for t,s in wanted]
                    assert all(bins)
                    expected=byrid[rid]['summaries'][label]['source_balanced' if source is None else 'by_source']
                    if source is not None:expected=expected[source]
                    for key in next(iter(metric_values.values())):
                        val=math.fsum(math.fsum(r[key] for r in group)/len(group) for group in bins)/len(bins)
                        error=abs(val-expected[key]);max_error=max(max_error,error)
                        assert error<1e-12,(rid,label,source,key,val,expected[key])
                        checked+=1
assert checked==9360
result={'passed':True,'direct_float32_array_endpoint_checks':checked,'maximum_absolute_error':max_error,
        'metrics_checked':['four query legal top1, 2/3 pools','both-polarity product before averaging, 2/3 pools','A_missing_error','B_present_error'],
        'coverage':'52 configurations ×5 type/overall scopes ×3 source/balanced scopes ×12 metrics',
        'aggregation_code_used':'separate direct numpy implementation; original aggregate/metric functions not imported',
        'source_type_weights_preserved':True,'unknown_or_excluded_families_included':False,'model_or_optimizer_used':False}
print(json.dumps(result,ensure_ascii=False))
